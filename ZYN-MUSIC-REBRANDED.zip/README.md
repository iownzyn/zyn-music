# 𝐙𝐘𝐍 𝐌𝐔𝐒𝐈𝐂 🎧

Telegram voice-chat music bot, rebranded for ZYN MUSIC. The existing bot modules and commands are retained; the internal `SayaMusic` Python package path is intentionally unchanged so imports and existing functionality keep working.

**Owner:** Aryan Malik (`@shadowxtemp`, ID `9100108789`)  
**Bot:** `@ZynMusicBot`  
**Support:** https://t.me/zynmusicupdates  
**Repository:** https://github.com/iownzyn/zyn-music

## Included features

- Voice-chat audio/video playback and queue controls
- Multi-source search/playback integrations present in the original source
- Group admin music controls and utility modules
- Sudo/manager controls and broadcast module present in the original source
- MongoDB-backed settings and user/chat data
- Docker and worker-process deployment files

This package preserves the upstream MIT license and notices. It is a rebrand/fork; it does not claim authorship of the upstream code.

## Required Render environment variables

Set these in Render → your Background Worker → Environment. Do not put secrets in GitHub.

| Variable | Value |
|---|---|
| `API_ID` | From https://my.telegram.org |
| `API_HASH` | From https://my.telegram.org |
| `BOT_TOKEN` | Token from BotFather |
| `MONGO_DB_URI` | Your MongoDB connection URI |
| `STRING_SESSION` | Assistant account session string |
| `OWNER_ID` | `9100108789` |
| `OWNER_USERNAME` | `shadowxtemp` |
| `BOT_USERNAME` | `ZynMusicBot` (without @) |
| `BOT_NAME` | `𝐙𝐘𝐍 𝐌𝐔𝐒𝐈𝐂 🎧` |
| `LOGGER_ID` | `-1004420640566` |
| `SUPPORT_CHANNEL` | `https://t.me/zynmusicupdates` |
| `SUPPORT_CHAT` | `https://t.me/zynmusicupdates` |
| `UPSTREAM_REPO` | `https://github.com/iownzyn/zyn-music` |
| `UPSTREAM_BRANCH` | `main` |

Optional: `COOKIE_URL`, `API_URL`, `VIDEO_API_URL`, `API_KEY`, `DEEP_API`, `SPOTIFY_CLIENT_ID`, `SPOTIFY_CLIENT_SECRET`.

## Deploy on Render

1. Upload the **contents** of this ZIP to the root of `iownzyn/zyn-music` (not the enclosing folder).
2. In Render, create **New → Background Worker** and connect that GitHub repository.
3. Use the repository's Dockerfile (Docker runtime). If using native Python instead, build command: `pip install -r requirements.txt`; start command: `python -m SayaMusic`.
4. Add the environment variables listed above.
5. Deploy.

A Background Worker is the correct service type for a continuously running bot. A free web service may sleep and is not a reliable 24/7 worker.

## Important first-start requirements

- Add the bot and assistant user account to the logger group `-1004420640566`; grant the required admin permissions.
- The original startup routine attempts a voice-chat stream in the logger group. Turn on a voice chat there before startup, otherwise the original code may exit.
- A valid assistant `STRING_SESSION` is required; the bot token alone is not enough.
- MongoDB must be reachable from Render.
- Never commit API hashes, bot tokens, session strings, database URIs, or cookies.

## Run locally

```bash
pip install -r requirements.txt
python -m SayaMusic
```

## License

See the preserved `LICENSE` file. Keep the upstream copyright/license notices when redistributing.
